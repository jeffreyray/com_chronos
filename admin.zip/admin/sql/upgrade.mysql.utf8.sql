ALTER TABLE `chr_briefings` ADD (
    `params` text NOT NULL DEFAULT '',
    `alias` VARCHAR(255) ,
    `active` TINYINT DEFAULT 1 ,
    `creation_date` DATE ,
    `modification_date` DATE ,
    `created_by` INT(11) ,
    `modified_by` INT(11) ,
    `access` INT(11) DEFAULT 2
);



ALTER TABLE `chr_studies` ADD (
    `umbrella` INT(11)
);

UPDATE `chr_studies` SET active = 0 WHERE finish_date IS NOT NULL;

ALTER TABLE `chr_facilities` ADD (
    `alias` VARCHAR(255) ,
    `published` TINYINT DEFAULT 1 ,
    `access` INT(11) DEFAULT 2 ,
    `created_by` INT(11) ,
    `modified_by` INT(11) ,
    `creation_date` DATE ,
    `modification_date` DATE
);

ALTER TABLE `chr_employees` ADD (
    `contact_info` TEXT
);

ALTER TABLE `chr_employees` ADD (
    `image` VARCHAR(255) ,
    `active` TINYINT DEFAULT 1 ,
    `hire_date` DATE ,
    `alt_hire_date` DATE ,
    `termination_date` DATE ,
    `termination_reason` INT(11) ,
    `termination_note` TEXT ,
    `referral_source` INT(11) ,
    `referrer` INT(11) ,
    `access` INT(11) DEFAULT 2 ,
    `created_by` INT(11) ,
    `creation_date` DATE ,
    `modified_by` INT(11) ,
    `modification_date` DATE ,
    `checked_out` INT(11) NOT NULL DEFAULT 0 ,
    `checked_out_time` DATETIME,
    `contact_info` TEXT
);

UPDATE `chr_employees`, `chr_hires` SET
    chr_employees.hire_date = chr_hires.date,
    chr_employees.alt_hire_date = chr_hires.revised_date,
    chr_employees.referrer = chr_hires.referrer,
    chr_employees.referral_source = chr_hires.referral_source
    WHERE chr_employees.id = chr_hires.id;
    
UPDATE `chr_employees`, `chr_terminations` SET
    chr_employees.termination_date = chr_terminations.date,
    chr_employees.termination_reason = chr_terminations.reason
    WHERE chr_employees.id = chr_terminations.id;
    
  

    
UPDATE `chr_employees` SET
    active = 0
    WHERE termination_date IS NOT NULL;


ALTER TABLE `chr_positions` ADD (
    `params` text NOT NULL DEFAULT '',
    `alias` VARCHAR(255) ,
    `published` TINYINT,
    `description` TEXT DEFAULT '',
    `active` TINYINT DEFAULT 1
);

CREATE TABLE IF NOT EXISTS `chr_positions` (
	`active` TINYINT DEFAULT 1
);

ALTER TABLE `chr_projectmanagers` ADD (
	`params` text NOT NULL DEFAULT '',
	`contact_info` TEXT ,
	`note` TEXT ,
	`active` TINYINT DEFAULT 1 ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`created_by` INT(11) ,
	`created_by_1` INT(11) ,
	`modified_by` INT(11) 
);


ALTER TABLE `chr_referralsources` ADD (
    `params` text NOT NULL DEFAULT '',
    `alias` VARCHAR(255) ,
    `published` TINYINT ,
    `ordering` INT(11) ,
    `default` TINYINT ,
    `note` TEXT DEFAULT ''
);



ALTER TABLE `chr_wages` ADD (
	`params` text NOT NULL DEFAULT '',
	`access` INT(11) DEFAULT 1 ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`created_by` INT(11) ,
	`modified_by` INT(11)
);

ALTER TABLE `chr_wagereasons` ADD (
	`params` text NOT NULL DEFAULT '',
	`alias` VARCHAR(255) ,
	`published` TINYINT DEFAULT 1 ,
	`ordering` INT(11) 
);



ALTER TABLE `chr_scheduledshifts` ADD (
	`params` text NOT NULL DEFAULT '',
	`comment` TEXT ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`access` INT(11) DEFAULT 2 ,
	`created_by` INT(11) ,
	`modified_by` INT(11)
);

ALTER TABLE `chr_shifttypes` ADD (
	`params` text NOT NULL DEFAULT '',
	`alias` VARCHAR(255) DEFAULT '255' ,
	`published` TINYINT DEFAULT 1 ,
	`ordering` INT(11) ,
	`access` INT(11) DEFAULT 1 ,
	`default` TINYINT DEFAULT 0 
);



ALTER TABLE `chr_terminationreasons` ADD (
    `params` text NOT NULL DEFAULT '',
    `alias` VARCHAR(255) ,
    `published` TINYINT ,
    `ordering` INT(11) ,
    `default` TINYINT ,
    `note` TEXT
);




















CREATE TABLE IF NOT EXISTS `chr_scheduledshifts` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`employee` INT(11) ,
	`shift_type` INT(11) ,
	`start` DATETIME NOT NULL ,
	`end` DATETIME NOT NULL ,
	`break_length` INT(11) DEFAULT 0 ,
	`comment` TEXT ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`access` INT(11) DEFAULT 1 ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_shifttypes` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) DEFAULT '255' ,
	`published` TINYINT DEFAULT 1 ,
	`ordering` INT(11) ,
	`access` INT(11) DEFAULT 1 ,
	`default` TINYINT DEFAULT 0 ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_wages` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`employee` INT(11) NOT NULL ,
	`date_effective` DATE NOT NULL ,
	`reason` INT(11) ,
	`value` DECIMAL(3,2 ) NOT NULL ,
	`comment` TEXT ,
	`access` INT(11) DEFAULT 1 ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_wagereasons` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`published` TINYINT DEFAULT 1 ,
	`ordering` INT(11) ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_workedshifts` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`employee` INT(11) ,
	`facility` INT(11) ,
	`time_in` DATETIME ,
	`time_out` DATETIME ,
	`break_length` INT(11) ,
	`scheduled_shift` INT(11) ,
	`comment` TEXT ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`access` INT(11) DEFAULT 1 ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_referralsources` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) ,
	`alias` VARCHAR(255) ,
	`published` TINYINT ,
	`ordering` INT(11) ,
	`default` TINYINT ,
	`note` TEXT ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_terminationreasons` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`published` TINYINT ,
	`ordering` INT(11) ,
	`default` TINYINT ,
	`note` TEXT ,

	PRIMARY KEY  (`id`)
);

ALTER TABLE `chr_productivities` ADD (
	`params` text NOT NULL DEFAULT '',
	`source` VARCHAR(255) NOT NULL DEFAULT '1' ,
	`creation_date` DATE ,
	`created_by` INT(11) ,
	`modification_date` DATE ,
	`modified_by` INT(11)
);

UPDATE `chr_productivities` SET `source` = 1 WHERE `source` != 1;



