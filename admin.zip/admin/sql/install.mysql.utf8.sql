CREATE TABLE IF NOT EXISTS `chr_studies` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`number` VARCHAR(20) ,
	`title` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`facility` INT(11) ,
	`client` INT(11) ,
	`tags` VARCHAR(255) ,
	`start_date` DATE ,
	`deadline` DATE ,
	`finish_date` DATE ,
	`briefing` INT(11) ,
	`active` TINYINT DEFAULT 1 ,
	`display` TINYINT DEFAULT 1 ,
	`published` TINYINT DEFAULT 1 ,
	`cati_code` VARCHAR(32) ,
	`cost_code` VARCHAR(32) ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,
	`access` INT(11) DEFAULT 1 ,
	`note` TEXT ,
	`primary_manager` INT(11) ,
	`secondary_manager` INT(11) ,
	`quota` INT(11) ,
	`target_cph` DECIMAL(3,2 ) ,
	`target_length` DECIMAL(3,2 ) ,
	`target_incidence` DECIMAL(3,2 ) ,
	`tier` VARCHAR(255) DEFAULT '1' ,
	`final_cph` DECIMAL(3,2 ) ,
	`final_length` DECIMAL(3,2 ) ,
	`completes` INT(11) ,
	`final_incidence` DECIMAL(3,2 ) ,

	PRIMARY KEY  (`id`),
	UNIQUE(number, alias)
);

CREATE TABLE IF NOT EXISTS `chr_facilities` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`published` TINYINT DEFAULT 1 ,
	`access` INT(11) DEFAULT 1 ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,
	`creation_date` DATE ,
	`modification_date` DATE ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_employees` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`number` INT(11) ,
	`tags` VARCHAR(255) ,
	`first_name` VARCHAR(64) NOT NULL ,
	`middle_name` VARCHAR(64) ,
	`last_name` VARCHAR(64) NOT NULL ,
	`facility` INT(11) ,
	`position` INT(11) ,
	`birth_date` DATE ,
	`image` VARCHAR(255) ,
	`active` TINYINT DEFAULT 1 ,
	`gender` VARCHAR(255) DEFAULT 'f' ,
	`hire_date` DATE ,
	`alt_hire_date` DATE ,
	`passed_probation` DATE ,
	`termination_date` DATE ,
	`termination_reason` INT(11) ,
	`referral_source` INT(11) ,
	`referrer` INT(11) ,
	`tier` VARCHAR(255) DEFAULT '1' ,
	`note` TEXT ,
	`contact_info` TEXT ,
	`access` INT(11) DEFAULT 1 ,
	`created_by` INT(11) ,
	`creation_date` DATE ,
	`modified_by` INT(11) ,
	`modification_date` DATE ,
	`checked_out` INT(11) NOT NULL DEFAULT 0 ,
	`checked_out_time` DATETIME ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_clients` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`name` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`tags` VARCHAR(255) ,
	`published` TINYINT DEFAULT 1 ,
	`access` INT(11) DEFAULT 1 ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,
	`note` TEXT ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_positions` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`description` TEXT ,
	`active` TINYINT ,

	PRIMARY KEY  (`id`)
);

ALTER TABLE `chr_scheduledshifts` ADD (
	`params` text NOT NULL DEFAULT '',
	`comment` TEXT ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`access` INT(11) DEFAULT 1 ,
	`created_by` INT(11) ,
	`modified_by` INT(11)
);

CREATE TABLE IF NOT EXISTS `chr_shifttypes` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) DEFAULT '255' ,
	`published` TINYINT DEFAULT 1 ,
	`ordering` INT(11) ,
	`access` INT(11) DEFAULT 1 ,
	`default` TINYINT DEFAULT 0 ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_wages` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`employee` INT(11) NOT NULL ,
	`date_effective` DATE NOT NULL ,
	`reason` INT(11) ,
	`value` DECIMAL(3,2 ) NOT NULL ,
	`comment` TEXT ,
	`access` INT(11) DEFAULT 1 ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_wagereasons` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`published` TINYINT DEFAULT 1 ,
	`ordering` INT(11) ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_workedshifts` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`employee` INT(11) ,
	`facility` INT(11) ,
	`time_in` DATETIME ,
	`time_out` DATETIME ,
	`break_length` INT(11) ,
	`scheduled_shift` INT(11) ,
	`comment` TEXT ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`access` INT(11) DEFAULT 1 ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_referralsources` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) ,
	`alias` VARCHAR(255) ,
	`published` TINYINT ,
	`ordering` INT(11) ,
	`default` TINYINT ,
	`note` TEXT ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_terminationreasons` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`label` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`published` TINYINT ,
	`ordering` INT(11) ,
	`default` TINYINT ,
	`note` TEXT ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_projectmanagers` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`first_name` VARCHAR(255) ,
	`last_name` VARCHAR(255) ,
	`display_name` VARCHAR(255) ,
	`email` VARCHAR(255) ,
	`contact_info` TEXT ,
	`note` TEXT ,
	`active` TINYINT DEFAULT 1 ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`created_by` INT(11) ,
	`created_by_1` INT(11) ,
	`modified_by` INT(11) ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_briefings` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`title` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`tags` VARCHAR(255) ,
	`active` TINYINT DEFAULT 1 ,
	`description` TEXT ,
	`last_used` DATE ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,
	`access` INT(11) DEFAULT 2 ,

	PRIMARY KEY  (`id`)
);


CREATE TABLE IF NOT EXISTS `chr_umbrellas` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`title` VARCHAR(255) NOT NULL ,
	`alias` VARCHAR(255) ,
	`number` VARCHAR(32) ,
	`facility` INT(11) ,
	`client` INT(11) ,
	`note` TEXT ,
	`active` TINYINT DEFAULT 1 ,
	`creation_date` DATE ,
	`modification_date` DATE ,
	`created_by` INT(11) ,
	`modified_by` INT(11) ,

	PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS `chr_productivities` (
	`id` int(11) NOT NULL auto_increment,
	`params` text NOT NULL DEFAULT '',
	`completes` INT(11) NOT NULL ,
	`cati_code` INT(11) ,
	`date` DATE ,
	`duration` INT(11) ,
	`employee` INT(11) ,
	`study` INT(11) ,
	`calls` INT(11) ,
	`source` VARCHAR(255) NOT NULL DEFAULT '1' ,
	`creation_date` DATE ,
	`created_by` INT(11) ,
	`modification_date` DATE ,
	`modified_by` INT(11) ,

	PRIMARY KEY  (`id`)
);
